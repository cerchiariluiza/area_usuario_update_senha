create database meubanco;
use  meubanco;
drop table usuarios;
create table usuarios (
  id int auto_increment primary key, 
 nome varchar(30),
 projeto varchar(50) NOT NULL,
departamento varchar(50) NOT NULL,
ramal varchar(50) NOT NULL,
salario varchar(50) NOT NULL,
status varchar(50) NOT NULL,
empresa varchar(50) NOT NULL,
usuario varchar(50) NOT NULL,
 telefone varchar(30),
 email varchar(30),
 senha varchar(40));
 
 