<?php
if(isset($_POST["user_id"])){
	include_once "conexao.php";
	
	$resultado = '';
	
	$query_user = "SELECT * FROM usuarios WHERE id = '" . $_POST["user_id"] . "' LIMIT 1";
	$resultado_user = mysqli_query($conn, $query_user);
	$row_user = mysqli_fetch_assoc($resultado_user);
	
	$resultado .= '<dl class="row">';
	
	$resultado .= '<dt class="col-sm-3">ID</dt>';
	$resultado .= '<dd class="col-sm-9">'.$row_user['id'].'</dd>';
	
	$resultado .= '<dt class="col-sm-3">Nome</dt>';
	$resultado .= '<dd class="col-sm-9">'.$row_user['nome'].'</dd>';
	
	$resultado .= '<dt class="col-sm-3">E-mail</dt>';
	$resultado .= '<dd class="col-sm-9">'.$row_user['email'].'</dd>';
	
	$resultado .= '<dt class="col-sm-3">Alterar senha</dt>';
	$resultado .= '<dd class="col-sm-9">
	
	
	<form action="alterar.php" method="post">
	<input type="hidden" name="id" value="'.$row_user['id'].'">
	<input type="password" name="senha" placeholder="alterar senha"></dd>
	<input type="submit" class="btn btn-outline-primary view_data" style="padding-left:40px;padding-right:40px">';
		
	$resultado .= '</dl>';
	
	echo $resultado;
}