<?php
	session_start();
		$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$banco = "meubanco";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $banco);	
	if(!$conn){
		die("Falha na conexao: " . mysqli_connect_error());
	}else{
		//echo "Conexao realizada com sucesso";
	}
?>


<!DOCTYPE html>
<html dir="ltr" lang="en-US">

<head>
    <!-- Metas -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="LionCoders" />
    <!-- Links -->
 
    <!-- google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800" rel="stylesheet">
    <!-- Plugins CSS -->
    <link href="css/plugin.css" rel="stylesheet" />
    <!-- style CSS -->
    <link href="css/style.css" rel="stylesheet" />
    <!--color switcher css-->
    <link rel="stylesheet" href="css/switcher/skin-aqua.css" media="screen" id="style-colors" />
    <!-- Document Title -->
    <title>Sistema</title>
	
	



	
</head>

<body onload="myFunction()">
    
    
    <!--Preloader ends-->
    <!--Page Wrapper starts-->
    <div class="page-wrapper">
          <!--header starts-->
        
        <!--Header ends-->
        <!--User Login section starts-->
        <div class="user-login-section section-padding bg-fixed" >
            <div class="container">
                <div class="row">
                    <div class="col-md-10 offset-md-1  text-center">
                        <div class="login-wrapper">
                            <ul class="ui-list nav nav-tabs justify-content-center mar-bot-30" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="tab" href="#login" role="tab" aria-selected="true">Login</a>
                                </li>
                               
                            </ul>
                            <div class="ui-dash tab-content">
                                <div class="tab-pane fade show active" id="login" role="tabpanel">
                                    <form id="login-form" action="valida.php" method="post">
                                        <div class="form-group">
                                            <input type="text" name="email" id="email" tabindex="1" class="form-control" placeholder="email" value="" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="senha" id="senha" tabindex="2" class="form-control" placeholder="Password">
                                        </div>
                                        <div class="row mar-top-20">
                                            <div class="col-md-6 col-12 text-left">
                                                <div class="res-box">
                                                    <input type="checkbox" tabindex="3" class="" name="remember" id="remember">
                                                    <label for="remember">Remember Me</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-12 text-right">
                                                <div class="res-box sm-left">
                                                  
                                                </div>
                                            </div>
                                        </div>
                                        <div class="res-box text-center mar-top-30">
                                            <button type="submit" name="entrar" class="btn v3"><i class="ion-log-in"></i> Log In</button>
                                        </div>
                                    </form>
                                    <div class="social-profile-login text-center mar-top-30">
                                        <p class="text-center text-danger">
			<?php if(isset($_SESSION['loginErro'])){
				echo $_SESSION['loginErro'];
				unset($_SESSION['loginErro']);
			}?>
		</p>
		<p class="text-center text-success">
			<?php 
			if(isset($_SESSION['logindeslogado'])){
				echo $_SESSION['logindeslogado'];
				unset($_SESSION['logindeslogado']);
			}
			?>
		</p>
                                       
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--User login section ends-->
        <!--Login section ends-->
        <!-- Scroll to top starts-->
        <span class="scrolltotop"><i class="ion-arrow-up-c"></i></span>
        <!-- Scroll to top ends-->
    </div>
    <!--Page Wrapper ends-->
    <!--Footer Starts-->
    
    <!--Color switcher starts-->
    <div class="color-switcher hide-color-switcher">
        <a class="switcher-button"><i class="ion-android-settings"></i></a>
        <div class="color-switcher-title text-center">
            <h5>Switch Colors</h5>
        </div>
        <div class="color-list text-center">
            <a class="color green-theme" title="green"></a>
            <a class="color red-theme" title="red"></a>
            <a class="color blue-theme" title="blue"></a>
            <a class="color orange-theme" title="orange"></a>
            <a class="color pink-theme" title="pink"></a>
            <a class="color purple-theme" title="purple"></a>
            <a class="color violet-theme" title="violet"></a>
            <a class="color aqua-theme" title="aqua"></a>
        </div>
    </div>
    <!--Color switcher ends-->
    <!--Scripts starts-->
    <!--plugin js-->
    <script src="js/plugin.js"></script>
    <!--google maps-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD_8C7p0Ws2gUu7wo0b6pK9Qu7LuzX2iWY&amp;libraries=places&amp;callback=initAutocomplete"></script>
    <!--Main js-->
    <script src="js/main.js"></script>
    <!--Scripts ends-->
		<script>
function mudarPagina()
{
alert("Você está sendo direcionado para outra página.\n Não se preocupe, esta ficará aberta também!");
window.open('https://www.imobiplaces.com.br/', 'pagina', "width=800, height=900, top=100, left=900, scrollbars=no " )
}
</script>
</body>

</html>
