	(function(A) {

	if (!Array.prototype.forEach)
		A.forEach = A.forEach || function(action, that) {
			for (var i = 0, l = this.length; i < l; i++)
				if (i in this)
					action.call(that, this[i], i, this);
			};

		})(Array.prototype);

		var
		mapObject,
		markers = [],
		markersData = {
			'Marker': [
		
		{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Ibatiba,234 - Vila MetalÃºrgica',
				location_latitude: -23.6157714,
				location_longitude:-46.5392634,
				map_image_url: 'https://jetimgs.com/O4RTGdcfco33Tmr6SiIr7VpwUV0yPGkqiR2ayuG6enn-efktp4FXidd9Zeo/sala_-_e_-_quarto.jpg',
				rate: '4',
				name_point: 'Rua Ibatiba, 234 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/ABC123',
				review:  'Vagas - 2',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Ibatiba,234 - Vila MetalÃºrgica',
				location_latitude: -23.6157714,
				location_longitude:-46.5392634,
				map_image_url: 'https://jetimgs.com/O4RRFNsccYX2TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/img_-_20180905_-_wa0020.jpg',
				rate: '4',
				name_point: 'Rua Ibatiba, 234 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/CS5A03B26L49O7IMPE18',
				review:  'Vagas - 2',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Itanha&eacute;m,30/80 - Parque Ja&ccedil;atuba',
				location_latitude: -23.6475829,
				location_longitude:-46.5114842,
				map_image_url: 'https://jetimgs.com/O4RQHNMed43-TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/fachada.jpg',
				rate: '4',
				name_point: 'Rua Itanha&eacute;m, 30/80 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/M35PIC846SL7AE91O0B2',
				review:  'Vagas - 0',
			},
{
				type_point: 'Mau&aacute;',
				name: 'Avenida Papa Jo&atilde;o XXIII,2880 - Loteamento Industrial Coral',
				location_latitude: -23.6787129,
				location_longitude:-46.4696916,
				map_image_url: 'https://jetimgs.com/O4RQGdYccI_yTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/maua_-_sertaozinho.jpg',
				rate: '4',
				name_point: 'Avenida Papa Jo&atilde;o XXIII, 2880 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/9035POI78EMBCSA6L421',
				review:  'Vagas - 0',
			},
{
				type_point: 'Mau&aacute;',
				name: 'Avenida Jos&eacute; Fernando Medina Braga,100 - Jardim Isabella',
				location_latitude: -23.6757535,
				location_longitude:-46.4804605,
				map_image_url: 'https://jetimgs.com/O4RQHNcacor1TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/parque_-_sao_-_vicente.jpg',
				rate: '4',
				name_point: 'Avenida Jos&eacute; Fernando Medina Braga, 100 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/8PE2C59641S7I03ABMOL',
				review:  'Vagas - 0',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Avenida Dom Bosco,575 - Vila Lucinda',
				location_latitude: -23.6295769,
				location_longitude:-46.5162629,
				map_image_url: 'https://jetimgs.com/O4RTH9UfdIX3TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/vista_-_aerea.jpg',
				rate: '4',
				name_point: 'Avenida Dom Bosco, 575 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/S18IPB3CO9625L4EMA07',
				review:  'Vagas - 0',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Riachuelo,229 - Vila Assun&ccedil;&atilde;o',
				location_latitude: -23.6716003,
				location_longitude:-46.5284973,
				map_image_url: 'https://jetimgs.com/O4RQHtQYeojzTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/img_-_20181121_-_wa0041.jpg',
				rate: '4',
				name_point: 'Rua Riachuelo, 229 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/1L3845BOESP70A96M2IC',
				review:  'Vagas - 2',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Adri&aacute;tico,151 - Jardim do Est&aacute;dio',
				location_latitude: -23.6975812,
				location_longitude:-46.5148713,
				map_image_url: 'https://jetimgs.com/O4RQGdsbdY_-TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/img_-_20190202_-_wa0046.jpg',
				rate: '4',
				name_point: 'Rua Adri&aacute;tico, 151 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/OPA40LE8I2CM1B7935S6',
				review:  'Vagas - 1',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua LituÃ¢nia,170 - Parque das Na&ccedil;Ãµes',
				location_latitude: -23.6415355,
				location_longitude:-46.5184215,
				map_image_url: 'https://jetimgs.com/O4RQGdocdonwTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/capturar2.jpg',
				rate: '4',
				name_point: 'Rua LituÃ¢nia, 170 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/20MCO31LA4S8EBP695I7',
				review:  'Vagas - 0',
			},
{
				type_point: 'S&atilde;o Bernardo do',
				name: 'Zurich,78 - Tabo&atilde;o',
				location_latitude: -23.6549036,
				location_longitude:-46.5997056,
				map_image_url: 'https://jetimgs.com/O4RQGdoceo7-TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/img_-_20190204_-_wa0114.jpg',
				rate: '4',
				name_point: 'Zurich, 78 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/3M78BO24PE06CIAS9L15',
				review:  'Vagas - 1',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Campos Sales,400 - Centro',
				location_latitude: -23.6591097,
				location_longitude:-46.5233337,
				map_image_url: 'https://jetimgs.com/O4RQGtUTcI70TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/20190215_-_103220.jpg',
				rate: '4',
				name_point: 'Rua Campos Sales, 400 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/4250O7EBL31MP6SCAI98',
				review:  'Vagas - 1',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua AntÃ´nio Seixas Leite Ribeiro,29 - Jardim Alvorada',
				location_latitude: -23.6994273,
				location_longitude:-46.5239184,
				map_image_url: 'https://jetimgs.com/O4RTH9QSeovxTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/img_-_20190604_-_wa0008.jpg',
				rate: '4',
				name_point: 'Rua AntÃ´nio Seixas Leite Ribeiro, 29 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/B0S4PO36IE1L8M2C7A95',
				review:  'Vagas - 1',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Jaguari,113 - Jardim',
				location_latitude: -23.6460094,
				location_longitude:-46.5452474,
				map_image_url: 'https://jetimgs.com/O4RQG9sdcYTzTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/1.jpg',
				rate: '4',
				name_point: 'Rua Jaguari, 113 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/L5I917C8E0AS2OM4B36P',
				review:  'Vagas - 4',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Jaguari,113 - Jardim',
				location_latitude: -23.6460094,
				location_longitude:-46.5452474,
				map_image_url: 'https://jetimgs.com/O4RQG9sdcYX1TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/img_-_01.jpg',
				rate: '4',
				name_point: 'Rua Jaguari, 113 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/0OE4L365PI98M7B1AC2S',
				review:  'Vagas - 4',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Bras&iacute;lio Machado,22 - Vila Pr&iacute;ncipe de Gales',
				location_latitude: -23.6600578,
				location_longitude:-46.5491949,
				map_image_url: 'https://jetimgs.com/O4RQFNAdco_1TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/fachada.jpg',
				rate: '4',
				name_point: 'Rua Bras&iacute;lio Machado, 22 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/S6LI038M924PC1E7AOB5',
				review:  'Vagas - 0',
			},
{
				type_point: 'Mau&aacute;',
				name: 'das Ac&aacute;cias,50 - Jardim Haydee',
				location_latitude: -23.6929851,
				location_longitude:-46.4686908,
				map_image_url: 'https://jetimgs.com/O4RQFdYbcYzwTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/acibam.jpg',
				rate: '4',
				name_point: 'das Ac&aacute;cias, 50 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/9E1465SC738A2BO0LIMP',
				review:  'Vagas - 0',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Coronel Fernando Prestes,255 - Centro',
				location_latitude: -23.6638218,
				location_longitude:-46.530052,
				map_image_url: 'https://jetimgs.com/O4RTGNUfdIz_TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/capturar.jpg',
				rate: '4',
				name_point: 'Rua Coronel Fernando Prestes, 255 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/29B81PS0C73E45MAI6OL',
				review:  'Vagas - 0',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Avenida Portugal,1692 - Centro',
				location_latitude: -23.6674276,
				location_longitude:-46.5367034,
				map_image_url: 'https://jetimgs.com/O4RTHdIbdI3_TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/fachada.jpg',
				rate: '4',
				name_point: 'Avenida Portugal, 1692 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/M1260APB94O57CL8ISE3',
				review:  'Vagas - 0',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua David Campista,132 - Vila Guiomar',
				location_latitude: -23.6567589,
				location_longitude:-46.539009,
				map_image_url: 'https://jetimgs.com/O4RTHdEceor1TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/fachada.jpg',
				rate: '4',
				name_point: 'Rua David Campista, 132 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/SA2E7B358MI46PCL910O',
				review:  'Vagas - 2',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua David Campista,132 - Vila Guiomar',
				location_latitude: -23.6567589,
				location_longitude:-46.539009,
				map_image_url: 'https://jetimgs.com/O4RTHdEcdIv1TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/r.jpg',
				rate: '4',
				name_point: 'Rua David Campista, 132 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/91LB50E8P43AOMI6CS27',
				review:  'Vagas - 3',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua David Campista,132 - Vila Guiomar',
				location_latitude: -23.6567589,
				location_longitude:-46.539009,
				map_image_url: 'https://jetimgs.com/O4RTHdEce4zxTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/u.jpg',
				rate: '4',
				name_point: 'Rua David Campista, 132 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/69SCMI2A570B31E8P4LO',
				review:  'Vagas - 3',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua David Campista,132 - Vila Guiomar',
				location_latitude: -23.6567589,
				location_longitude:-46.539009,
				map_image_url: 'https://jetimgs.com/O4RTHdEcdIXzTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/5.jpg',
				rate: '4',
				name_point: 'Rua David Campista, 132 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/16MAE8OC0I75L429PS3B',
				review:  'Vagas - 3',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua David Campista,132 - Vila Guiomar',
				location_latitude: -23.6567589,
				location_longitude:-46.539009,
				map_image_url: 'https://jetimgs.com/O4RTHdEcdIrxTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/t.jpg',
				rate: '4',
				name_point: 'Rua David Campista, 132 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/E0BO6C9I58SML42PA731',
				review:  'Vagas - 3',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Kugler,113 - Vila Gilda',
				location_latitude: -23.670781,
				location_longitude:-46.537657,
				map_image_url: 'https://jetimgs.com/O4RTHdEddY3wTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/fachada.jpg',
				rate: '4',
				name_point: 'Rua Kugler, 113 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/SA59C0EP1462ML3BI7O8',
				review:  'Vagas - 2',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua das Figueiras,641 - Jardim',
				location_latitude: -23.646274,
				location_longitude:-46.541384,
				map_image_url: 'https://jetimgs.com/O4RSHtAdeo3zTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/img_-_20190912_-_151225.jpg',
				rate: '4',
				name_point: 'Rua das Figueiras, 641 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/4P8CL765O0BMA12ES3I9',
				review:  'Vagas - 0',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Avenida Portugal,572 - Centro',
				location_latitude: -23.6573933,
				location_longitude:-46.5301216,
				map_image_url: 'https://jetimgs.com/O4RTHtsTco7yTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/fachada.jpg',
				rate: '4',
				name_point: 'Avenida Portugal, 572 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/ESO7A91I04MB35PC82L6',
				review:  'Vagas - 0',
			},
{
				type_point: 'Mau&aacute;',
				name: 'Capit&atilde;o Jo&atilde;o,1815 - Matriz',
				location_latitude: -23.6752911,
				location_longitude:-46.4548073,
				map_image_url: 'https://jetimgs.com/O4RTH9Acdoj_TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/img_-_20181002_-_wa0018.jpg',
				rate: '4',
				name_point: 'Capit&atilde;o Jo&atilde;o, 1815 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/EB8209SCI37PLAMO5461',
				review:  'Vagas - 0',
			},
{
				type_point: 'Mau&aacute;',
				name: 'Avenida Capit&atilde;o Jo&atilde;o,1813 - Matriz',
				location_latitude: -23.6752911,
				location_longitude:-46.4548073,
				map_image_url: 'https://jetimgs.com/O4RTH9cdeo_3TmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/4.jpg',
				rate: '4',
				name_point: 'Avenida Capit&atilde;o Jo&atilde;o, 1813 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/61BLOS5240IE93MAC7P8',
				review:  'Vagas - 0',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Largo TrÃªs de Maio,151 - Vila Pires',
				location_latitude: -23.6757193,
				location_longitude:-46.5110163,
				map_image_url: 'https://jetimgs.com/O4RTH9YacIXzTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/2.jpg',
				rate: '4',
				name_point: 'Largo TrÃªs de Maio, 151 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/35L0A9B8241POI6C7MES',
				review:  'Vagas - 0',
			},
{
				type_point: 'Santo Andr&eacute;',
				name: 'Rua Muritinga,686 - Vila Floresta',
				location_latitude: -23.6725314,
				location_longitude:-46.5479197,
				map_image_url: 'https://jetimgs.com/O4RTGtofdI3zTmX6SiIr7VpwUV0zOWEqihWYyuG6enjzfv4qo41X1_8/img_-_20190710_-_143053.jpg',
				rate: '4',
				name_point: 'Rua Muritinga, 686 ',
				url_point:' https://api.imobiplaces.com.br/portal/property/3SI85E7AC120BOL694MP',
				review:  'Vagas - 8',
			}
			
			]

		};

			var mapOptions = {
				zoom: 10,
				center: new google.maps.LatLng(-23.6157714, -46.5392634),
				mapTypeId: google.maps.MapTypeId.ROADMAP,

				mapTypeControl: false,
				mapTypeControlOptions: {
					style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
					position: google.maps.ControlPosition.LEFT_CENTER
				},
				panControl: false,
				panControlOptions: {
					position: google.maps.ControlPosition.TOP_RIGHT
				},
				zoomControl: true,
				zoomControlOptions: {
					position: google.maps.ControlPosition.RIGHT_BOTTOM
				},
				scrollwheel: false,
				scaleControl: false,
				scaleControlOptions: {
					position: google.maps.ControlPosition.TOP_LEFT
				},
				streetViewControl: true,
				streetViewControlOptions: {
					position: google.maps.ControlPosition.LEFT_TOP
				},
				styles: [
  {
    "featureType": "administrative",
    "elementType": "geometry",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "labels",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "poi",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.icon",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "transit",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  }
]
			};
			var marker;
			mapObject = new google.maps.Map(document.getElementById('map_right_listing'), mapOptions);
			for (var key in markersData)
				markersData[key].forEach(function (item) {
					marker = new google.maps.Marker({
						position: new google.maps.LatLng(item.location_latitude, item.location_longitude),
						map: mapObject,
						icon: 'images/others/marker.png',
					});

					if ('undefined' === typeof markers[key])
						markers[key] = [];
					markers[key].push(marker);
					google.maps.event.addListener(marker, 'click', (function () {
				  closeInfoBox();
				  getInfoBox(item).open(mapObject, this);
				  mapObject.setCenter(new google.maps.LatLng(item.location_latitude, item.location_longitude));
				 }));

	});

	new MarkerClusterer(mapObject, markers[key]);
	
		function hideAllMarkers () {
			for (var key in markers)
				markers[key].forEach(function (marker) {
					marker.setMap(null);
				});
		};
	
	

		function closeInfoBox() {
			$('div.infoBox').remove();
		};

		function getInfoBox(item) {
			return new InfoBox({
				content:
				'<div class="marker_info" id="marker_info">' +
				'<img src="' + item.map_image_url + '" alt=""/>' +
				'<span>'+ 
					'<em>'+ item.type_point +'</em>' +
					'<h3><a href="'+item.url_point+'">'+ item.name_point +'</a></h3>' +
					'<span class="infobox_rate">'+ item.rate +'</span>' +
					'<span class="btn_infobox_reviews">'+ item.review +'</span>' +
					'</span>' +
				'</div>',
				disableAutoPan: false,
				maxWidth: 0,
				pixelOffset: new google.maps.Size(10, 92),
				closeBoxMargin: '',
				closeBoxURL: "images/others/close_infobox.png",
				isHidden: false,
				alignBottom: true,
				pane: 'floatPane',
				enableEventPropagation: true
			});
		};
function onHtmlClick(location_type, key){
     google.maps.event.trigger(markers[location_type][key], "click");
}
