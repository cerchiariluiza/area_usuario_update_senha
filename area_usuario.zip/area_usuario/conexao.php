<?php
$servidor = "Localhost";
$usuario = "id11657792_luiza";
$senha = "SzF(b1u933uLtLcp";
$dbname = "id11657792_trainning";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

/*
<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "meubanco";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);*/