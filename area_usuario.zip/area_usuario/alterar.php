<?php 
$id = $_POST['id'];

$senha =  $_POST['senha'];

;
if ($id>=1) {
//$con = mysqli_connect("localhost", "root", "","arizonwe_bdconsempi");
$con = mysqli_connect("localhost", "root", "","meubanco");


$sql = mysqli_query($con, "update `usuarios` SET senha = '$senha' where id = $id" );
  echo "<script>alert('Senha alterar com sucesso!');</script>";
	
echo "<script>window.location.href='area.php'</script>";
}
