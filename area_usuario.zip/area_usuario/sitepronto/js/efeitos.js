﻿/*Efeito caixas home*/
$(document).ready(function(){
	$(".solucoes .col-md-4, .solucoes .col-md-3").hover(
      function () {
		$(".col-md-4, .col-md-3").addClass("teste");
        $(this).addClass("active");				
		$(this).removeClass("teste");			
      },
      function () {
        $(this).removeClass("active");
		$(".col-md-4, .col-md-3").removeClass("teste");
      }
    );
});
/*Efeito listagem*/
$(document).ready(function() {
    $(".todos").click(function(){
		$(this).addClass("active");
		$(".propriedade-intelectual, .financas-e-tributos, .incentivos-de-longo-prazo, .outros").removeClass("active");
        $(".ilp, .financas, .pi, .outros").show(500);
    });
    $(".propriedade-intelectual").click(function(){
		$(this).addClass("active");
		$(".incentivos-de-longo-prazo, .financas-e-tributos, .todos, .outros").removeClass("active");
        $(".ilp, .financas, .outros").hide(500);
        $(".pi").show(500);
    });
    $(".incentivos-de-longo-prazo").click(function(){
		$(this).addClass("active");
		$(".propriedade-intelectual, .financas-e-tributos, .todos, .outros").removeClass("active");
        $(".pi, .financas, .outros").hide(500);
        $(".ilp").show(500);
    });
   $(".financas-e-tributos").click(function(){
	    $(this).addClass("active");
		$(".propriedade-intelectual, .incentivos-de-longo-prazo, .todos, .outros").removeClass("active");
        $(".pi, .ilp, .outros").hide(500);
        $(".financas").show(500);
    });
});

/*efeito carrossel*/
$(document).ready(function() {
      $("#clientes").owlCarousel({
		autoPlay: 3000,
       	 	items : 1,
        	itemsDesktop : [1199,1],
        	itemsDesktopSmall : [979,1],
		navigation : false,
		pagination : true,
		responsive: true,
	    	responsiveRefreshRate : 200,
    		responsiveBaseWidth: window,
		stopOnHover: true
      });
	  $("#conquistas").owlCarousel({
        	autoPlay: 3500,
       	 	items : 3,
        	itemsDesktop : [1199,3],
        	itemsDesktopSmall : [979,3],
		navigation : false,
		pagination : true,
		responsive: true,
	    	responsiveRefreshRate : 200,
    		responsiveBaseWidth: window,
		stopOnHover: true
      });	
	   $("#owl-demo").owlCarousel({
        	autoPlay: 3000,
        	items : 5,
        	itemsDesktop : [1199,3],
        	itemsDesktopSmall : [979,3],
		stopOnHover: true
      });
	   $("#depoimentos").owlCarousel({
		autoPlay: 10000,
       	 	items : 1,
        	itemsDesktop : [1199,1],
        	itemsDesktopSmall : [979,1],
		navigation : false,
		pagination : true,
		responsive: true,
	    	responsiveRefreshRate : 200,
    		responsiveBaseWidth: window,
		stopOnHover: true
      });
	$("#bannerinicio").owlCarousel({
		transitionStyle : "fade",
		autoPlay: 3500,
       	 	items : 1,
        	itemsDesktop : [1199,1],
        	itemsDesktopSmall : [979,1],
		navigation : false,
		pagination : false,
		responsive: true,
	    	responsiveRefreshRate : 200,
    		responsiveBaseWidth: window,
		stopOnHover: true
		
      });
	  $("#falando-sobre-a-pris").owlCarousel({
        	autoPlay: 3500,
        	items : 3,
        	itemsDesktop : [1199,3],
        	itemsDesktopSmall : [979,3],
		navigation : false,
		pagination : true,
		responsive: true,
	    responsiveRefreshRate : 200,
    	responsiveBaseWidth: window,
		stopOnHover: true
      });
	  $("#imagens-projecao-folha").owlCarousel({
       		autoPlay: 2500,
	        items : 1,
        	itemsDesktop : [1199,3],
	        itemsDesktopSmall : [979,3],
		navigation : false,
		pagination : true,
		responsive: true,
		responsiveRefreshRate : 200,
	    	responsiveBaseWidth: window,
		stopOnHover: true
      });
});
	


/*Menus*/
var ref = document.referrer;
if (document.referrer.indexOf('?name=pi') >= 0) {
	$("a.propriedade-intelectual").addClass("active");
	$(".financas, .incentivos-de-longo-prazo, .todos").removeClass("active");
	$(".financas, .ilp").hide(500);
	$(".pi").show(500);
	$("li.a-pris a, li.software a, li.cursos a, li.cases a, li.biblioteca a, li.blog a, li.contato a, .marca a").attr("href", function(index, oldValue){return oldValue + "?name=pi";});
}
else{ 
	
}

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll <= 0) {
        $(".navbar-fixed-top").removeClass("fullcolor");
    } else {
        $(".navbar-fixed-top").addClass("fullcolor");
    }
});

/*Mostra campo form patente*/
$(document).ready(function(){
		$('#checkpatente').change(function(){
		if(this.checked)
			$('#divpatente').fadeIn('slow');
		else
			$('#divpatente').fadeOut('slow');
		});
	});

/*Efeito desliza*/
	$(function() {
		$('.desliza').click(function(){
			$('html, body').animate({
			scrollTop: $( $(this).attr('href') ).offset().top
			}, 1000);
			return false;        
			});
	  });
	