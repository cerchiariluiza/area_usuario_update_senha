
<?php

include_once 'conexao.php';
$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
$telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
$senha = filter_input(INPUT_POST, 'senha', FILTER_SANITIZE_STRING);
$empresa = filter_input(INPUT_POST, 'empresa', FILTER_SANITIZE_STRING);
$usuario = filter_input(INPUT_POST, 'usuario', FILTER_SANITIZE_STRING);
$ramal = filter_input(INPUT_POST, 'ramal', FILTER_SANITIZE_STRING);
$departamento = filter_input(INPUT_POST, 'departamento', FILTER_SANITIZE_STRING);
$projeto = filter_input(INPUT_POST, 'projeto', FILTER_SANITIZE_STRING);
$status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);

$query_usuario = "INSERT INTO usuarios (nome, telefone, email, senha, departamento, usuario, ramal, projeto, empresa, status) VALUES ('$nome', '$telefone', '$email', '$senha', '$departamento', '$usuario', '$ramal', '$projeto', '$empresa', '$status')";

mysqli_query($conn, $query_usuario);
if(mysqli_insert_id($conn)){
$mensagem = "nome: ".$_POST['nome']." \n";
$mensagem .= "telefone: ".$_POST['telefone']." \n";
$mensagem .= "email:". $_POST['email'];
mail("docente.luiza@gmail.com", "Formulário de Contato Enviado pelo Site", $mensagem); 

echo '<p align="center" class="style6">Enviado com Sucesso!</p>';
echo '<p align="center" class="style6">Em breve entraremos em contato.</p>';

	echo true;

}else{
	echo false;

}

